class Escape:
    count = 0
    
    def __init__(self):
       pass 
    
    def run(self):
       pass 
        
        
    
        